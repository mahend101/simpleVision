﻿using FrameWork;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace InsightViewerNG
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public ViewModels.MainWindowViewModel VM
        {
            get
            {
                return (ViewModels.MainWindowViewModel)this.DataContext;
            }
        }

        private bool toggle = false;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (toggle)
            {
                VM.currentRowBtnLeft = 0;
                VM.currentRowBtnRight = 1;
            }
            else
            {
                VM.currentRowBtnLeft = 1;
                VM.currentRowBtnRight = 0;
            }

            toggle = !toggle;
        }
    }
}

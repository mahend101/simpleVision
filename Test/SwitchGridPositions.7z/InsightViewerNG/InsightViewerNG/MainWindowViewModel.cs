﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Framework;

namespace InsightViewerNG.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {


        #region fields


        #endregion //fields

        #region properties


        private int _currentRowBtnLeft;
        public int currentRowBtnLeft
        {
            get
            {
                return _currentRowBtnLeft;
            }
            set
            {
                _currentRowBtnLeft = value;
                OnPropertyChanged();
            }
        }


        private int _currentRowBtnRight;
        public int currentRowBtnRight
        {
            get
            {
                return _currentRowBtnRight;
            }
            set
            {
                _currentRowBtnRight = value;
                OnPropertyChanged();
            }
        }



        #endregion //properties
        #region methods


        #endregion //methods
    }
}
